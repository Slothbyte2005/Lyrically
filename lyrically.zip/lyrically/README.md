# lyrically

Light-weight lyrics web app, just enter the name of artist and song name, and it will give the lyrics of the song given.
And also get youtube video with the lyrics.
